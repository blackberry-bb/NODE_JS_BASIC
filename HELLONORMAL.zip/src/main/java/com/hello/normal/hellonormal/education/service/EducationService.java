package com.hello.normal.hellonormal.education.service;

import org.springframework.stereotype.Service;

@Service
public class EducationService {
}
