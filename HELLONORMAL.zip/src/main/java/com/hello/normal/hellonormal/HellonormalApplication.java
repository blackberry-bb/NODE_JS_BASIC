package com.hello.normal.hellonormal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellonormalApplication {



    public static void main(String[] args) {
        SpringApplication.run(HellonormalApplication.class, args);
    }

}
