package com.hello.normal.hellonormal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellonormalApplicationTests {

    @Test
    void contextLoads() {
    }

}
